#Grupo 5
#Henrique Lourenço - 77459
#José Touret - 78215

def n_grams(unigramsFile, bigramsFile, parameterization, sentences):
    words = []
    param = []
    unigrams = []
    bigrams = []
    text = []
    textIndex = -1
    with open(parameterization) as p: #Parametrization file
        data = p.read().split()
        word = data[0]
        param.append(data[1])
        param.append(data[2])
        param.append(data[4])
    #print("PARAM: ", param)#          Debug print

    with open(unigramsFile) as u: #Unigrams and respective values file
        for line in u.readlines():
            values = line.split()
            if (values[0] in param):
                unigrams.append(values)
    #print("UNIGRAMS: ", unigrams)#          Debug print

    with open(bigramsFile) as b: #Bigrams and respective values file
        for line in b.readlines():
            values = line.split()
            if (values[0] in param or values[1] in param):
                bigrams.append(values)
    #print("BIGRAMS: ", bigrams)#          Debug print

    with open(sentences) as f: #Text with sentences file
        for line in f.readlines():
	    text.append(line)
            sentence = line.split()
            index = sentence.index(word)
            aux = []
            if (index > 0):
                aux.append(sentence[index-1])
            aux.append(sentence[index])
            if (index + 1 < len(sentences)):
                aux.append(sentence[index+1])
            words.append(aux)
    #print("WORDS: ", words)#          Debug print
    
    for w in words:
        textIndex += 1
        bigram1 = 1
        bigram2 = 1
	unigram1 = 0
	unigram2 = 0
	lema1=""
	lema2=""
        option1 = w[:]
        index = option1.index(word)
        option1[index] = param[0]
        option2 = w[:]
        index = option2.index(word)
        option2[index] = param[1]
        for unigram in unigrams:
     		if(option1[1] in unigram):
        	        unigram1 = float(unigram[1])
		if(option2[1] in unigram):
        	        unigram2 = float(unigram[1])
        for bigram in bigrams:
            	if( (option1[0] == bigram[0] and option1[1] == bigram[1]) or (option1[1] == bigram[0] and option1[2] == bigram[1]) ):
                	bigram1 *= float(bigram[2])
            	elif( (option2[0] == bigram[0] and option2[1] == bigram[1]) or (option2[1] == bigram[0] and option2[2] == bigram[1]) ):
                	bigram2 *= float(bigram[2])
	if (unigram1 >= unigram2):
		lema1 = option1
	else:        
		lema1 = option2
	if (bigram1 >= bigram2):
		lema2 = option1
	else:        
		lema2 = option2
        print("O lema mais provavel usando unigramas para a frase \" " + "".join(text[textIndex]) + " \" e: " + " ".join(lema1)) #lema
	print("O valor para "+ str(option1[1]) + " usando unigramas = " + str(unigram1))
	print("O valor para "+ str(option2[1]) + " usando unigramas = " + str(unigram2))
       	print("O lema mais provavel usando bigramas para a frase \"" + "".join(text[textIndex]) + "\" e: " + " ".join(lema2)) #lema
	print("O valor para "+ str(option1[1]) + " usando bigramas = " + str(bigram1))
	print("O valor para "+ str(option2[1]) + " usando bigramas = " + str(bigram2))
    #print("SENTENCE: ", sentence)#          Debug print
